document.addEventListener("DOMContentLoaded", function () {
    const adoptionFormContainer = document.querySelector(".adoption-form-container");
    const adoptionForm = document.querySelector(".adoption-form");
    const submissionMessage = document.querySelector(".submission-message");
    const form = document.querySelector("#adoption-form");

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        // Set the submission message
        submissionMessage.textContent = "Thank you! We will contact you shortly.";

        // Optionally, you can reset the form fields after submission
        form.reset();

        // Scroll to the top of the form after submission
        adoptionForm.scrollTop = 0;
    });

    // Show the adoption form container when the "Adopt" button is clicked
    document.querySelectorAll(".primary-btn").forEach(function (button) {
        button.addEventListener("click", function () {
            adoptionFormContainer.style.display = "flex";
            adoptionForm.scrollTop = 0; // Scroll to the top of the form when it's displayed
        });
    });

    // Close the adoption form container when clicking outside of it
    adoptionFormContainer.addEventListener("click", function (e) {
        if (e.target === adoptionFormContainer) {
            adoptionFormContainer.style.display = "none";
        }
    });
});




    <script>
        const searchInput = document.getElementById('searchInput');
        const dropdownLinks = document.querySelectorAll('.dropdown-content a');
        const animalCards = document.querySelectorAll('.animal-card');

        // Event listener for the search input
        searchInput.addEventListener('input', filterCards);

        // Event listeners for dropdown links
        dropdownLinks.forEach(link => {
            link.addEventListener('click', function (event) {
                event.preventDefault();
                const filterValue = this.getAttribute('data-filter');
                filterCards(filterValue);
            });
        });

        // Function to filter and display cards based on search input and dropdown selection
        function filterCards(filterValue) {
            filterValue = filterValue.toLowerCase();
            const searchTerm = searchInput.value.toLowerCase();

            animalCards.forEach(card => {
                const cardSpecies = card.querySelector('.species-text').textContent.trim().toLowerCase();
                const cardTitle = card.querySelector('.card-title').textContent.trim().toLowerCase();

                if ((filterValue === 'all' || cardSpecies === filterValue) && (searchTerm === '' || cardTitle.includes(searchTerm))) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    </script>

    // JavaScript code can be added here to handle form submission or other interactions.
// This example adds a simple form submission handler.
document.getElementById("adoption-form").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent the default form submission behavior
    // You can add your custom logic here for form submission, validation, etc.
    // For demonstration purposes, we'll display a submission message.
    const submissionMessage = document.querySelector(".submission-message");
    submissionMessage.textContent = "Form submitted successfully!";
    submissionMessage.style.color = "green";
});

